   <div class="col-lg-4 col-md-6">
       <div class="single-product-wrap">
           <div class="thumb">
               <img src="assets/img/other/port2.jpeg" alt="img">
               <a class="cat" href="property-details.html">For Sell</a>
           </div>
           <div class="product-wrap-details">
               <div class="media">
                   <div class="author">
                       <img src="assets/img/author/1.png" alt="img">
                   </div>
                   <div class="media-body">
                       <h6><a href="#">Owner Name</a></h6>
                       <p><img src="assets/img/icon/location-alt.png" alt="img">Mbenzi </p>
                   </div>
                   <a class="fav-btn float-right" href="#"><i class="far fa-heart"></i></a>
               </div>
               <div class="product-meta">
                   <span class="price">TSH: 80,650.00</span>
                   <div class="float-right d-inline-block">
                       <ul>

                           <li><img src="assets/img/icon/wall.png" alt="img">1026 sq ft</li>
                       </ul>
                   </div>
               </div>
           </div>
       </div>
   </div>
